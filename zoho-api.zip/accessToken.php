<?php


$client_id = '1000.KSHB4TS03YLP6HWR1WIM45JT5MQUOC';
$client_secret = '2cdfcf789cb27a5355a3275a5cf5511c31a07e5652';
$token_url = 'https://accounts.zoho.com/oauth/v2/token';
$refresh_token = '1000.f1210aba865ffc2a7c9823a0ab6c9a09.cc36882ca2ac73e57b7333cb40e25d3e'; // Ensure this is securely stored

$accessToken = getStoredTokenData('accessToken.json',$refresh_token, $client_id, $client_secret, $token_url);








function refreshAccessToken($refresh_token, $client_id, $client_secret, $token_url) {
    $data = [
        'grant_type' => 'refresh_token',
        'refresh_token' => $refresh_token,
        'client_id' => $client_id,
        'client_secret' => $client_secret,
    ];

    $options = [
        'http' => [
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ],
    ];

    $context  = stream_context_create($options);
    $result = file_get_contents($token_url, false, $context);

    if ($result === FALSE) {
        $error = error_get_last();
        echo 'Error: ' . print_r($error, true);
        return false;
    }

    $out = json_decode($result, true); 
    $expires_in = $out['expires_in'];
    $current_time = time(); // Get the current timestamp
    $expiration_time = $current_time + $expires_in;
    $out['expiration_time'] = $expiration_time;
    file_put_contents('accessToken.json',json_encode($out));

    return $access_token = $out['access_token'];

    
}


function getAccessToken($code, $client_id, $client_secret, $redirect_uri, $token_url) {
    $data = [
        'grant_type' => 'authorization_code',
        'code' => $code,
        'redirect_uri' => $redirect_uri,
        'client_id' => $client_id,
        'client_secret' => $client_secret,
    ];

    $options = [
        'http' => [
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ],
    ];

    $context  = stream_context_create($options);
    $result = file_get_contents($token_url, false, $context);

    if ($result === FALSE) {
        $error = error_get_last();
        echo 'Error: ' . print_r($error, true);
        return false;
    }

    return $result;
}


function storeTokenData($access_token, $expiry_timestamp, $filename = 'accessToken.json') {
    $token_data = [
        'access_token' => $access_token,
        'expiry_timestamp' => $expiry_timestamp,
    ];

    $json_data = json_encode($token_data, JSON_PRETTY_PRINT);
    
    file_put_contents($filename, $json_data);
}

function getStoredTokenData($filename = 'accessToken.json',$refresh_token, $client_id, $client_secret, $token_url) {
    
    if (!file_exists($filename)) {
        $token =  refreshAccessToken($refresh_token, $client_id, $client_secret, $token_url);     
        return $token;    
    }

    $json_data = file_get_contents($filename);
    $out = json_decode($json_data, true);

    if(time() >= $out['expiration_time']){        
        $token =  refreshAccessToken($refresh_token, $client_id, $client_secret, $token_url);
        return $token;
    }
   
    return $access_token = $out['access_token'];
    
}



