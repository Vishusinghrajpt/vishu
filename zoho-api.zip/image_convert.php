<?php

// Hexadecimal string
$hex_string = "41c1dcb79fac553e60cebb0d93f347af933ea4fde237b414f0d835dbba70ffdb9f3fe7216e58da27a10c0ca6151d3ef470fda73742ddff643902d00e13d6f9dd59a03df4fc5bb049e3a3047bc8c50951";

// Convert hex to binary
$binary_data = hex2bin($hex_string);

// Define the file name and path (e.g., image.png)
$file_name = "image.png";

// Save the binary data as an image file
file_put_contents($file_name, $binary_data);

echo "Image has been saved as $file_name";


?>
