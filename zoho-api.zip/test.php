<?php 
include 'accessToken.php';


$data = file_get_contents("accessToken.json");
$access_token=json_decode($data,true);



$AccessToken=$access_token['access_token'];


$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://www.zohoapis.com/crm/v7/Property_Listing/6360002000000818070',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30, // Adjusted timeout to 30 seconds
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_HTTPHEADER => array(
        "Authorization: Zoho-oauthtoken $AccessToken",
        'Content-Type: application/json',
    ),
));

$response = curl_exec($curl);

if ($response === false) {
    // Output cURL error if it occurs
    echo 'cURL Error: ' . curl_error($curl);
} else {
    // Check HTTP response code
    $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    if ($http_code == 200) {
        // Decode and print JSON data
        $data = json_decode($response, true);
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    } else {
        echo 'HTTP Error Code: ' . $http_code;
        echo "<pre>";
        print_r($response);
        echo "</pre>";
    }
}

curl_close($curl);



