<?php

include 'accessToken.php';


$data = file_get_contents("accessToken.json");
$access_token=json_decode($data,true);



$AccessToken=$access_token['access_token'];


/*echo "<pre>";
print_r($AccessToken);
echo "</pre>";

//die();

*/

$curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://www.zohoapis.com/crm/v2.1/Property_Listing/6360002000000818070/photo',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET', 
        CURLOPT_HTTPHEADER => array(
             "Authorization: Zoho-oauthtoken $AccessToken",
            'Content-Type: application/json',
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    $data =json_decode($response,true);

    curl_close($curl);

    echo "<pre>";
    print_r($data);
    echo "</pre>";


?>


