<?php

    require('../wp-load.php');

    ini_set("display_errors", 1);
    ini_set("display_startup_errors", 1);
    error_reporting(E_ALL);



        $data =file_put_contents('zoho.log',file_get_contents('php://input'));
        $data = file_get_contents("zoho.log");

        parse_str($data, $parsedData);

        // Convert the parsed data to JSON
        $jsonData = json_encode($parsedData, JSON_PRETTY_PRINT);
        $arrayData = json_decode($jsonData, true);




       // Extract data

        $Property_listing_Id = $arrayData['Property_listing_Id'];
        $Owner = $arrayData['Owner'];
        $price = $arrayData['price'];
        $Price_per_sqft = $arrayData['Price_per_sqft'];
        $Modified = $arrayData['Modified'];
        $year = $arrayData['year'];
        $es_property_area = $arrayData['es_property_area'];
        $es_property_floors = $arrayData['es_property_floors'];
        //$high = $arrayData['high'];
        $title = $arrayData['title'];
        $floors = $arrayData['floors'];
        $rate = $arrayData['rate'];
        $es_property_price_per_sqft = $arrayData['es_property_price_per_sqft'];
        $annual = $arrayData['annual'];
        $es_property_bedrooms = $arrayData['es_property_bedrooms'];
        $es_property_bathrooms = $arrayData['es_property_bathrooms'];
        $heating = $arrayData['heating'];
        $garage = $arrayData['garage'];
        //$elementory = $arrayData['elementory'];
        //$secondary = $arrayData['secondary'];
        $management = $arrayData['management'];
        $post_id = $arrayData['post_id'];
        $cooling = $arrayData['cooling'];
        $floor_level = $arrayData['floor_level'];
        $category = $arrayData['category'];
        $address=$arrayData['address'];
        $price_note=$arrayData['price_note'];


            

            // Define meta fields
        $meta_fields = [
            'Property_listing_Id' => $Property_listing_Id,
            'Owner' => $Owner,
            'es_property_price'=> $price,
            'Price_per_sqft' => $Price_per_sqft,
            'es_property_price_note'=>$price_note,
            'Modified' => $Modified,
            'es_property_year_built' => $year,
            'es_property_area' => $es_property_area,
            'es_property_floors' => $es_property_floors,
            //'es_property_high-school' => $high,
            'title' => $title,
            'floors' => $floors,
            'es_property_address'=>$address,
            'es_property_cap-rate' => $rate,
            'es_property_price_per_sqft' => $es_property_price_per_sqft,
            'es_property_annual-roi' => $annual,
            'es_property_bedrooms' => $es_property_bedrooms,
            'es_property_bathrooms' => $es_property_bathrooms,
            'es_property_heating-features' => $heating,
            'es_property_garage-spaces' => $garage,
            //'es_property_elementary-school' => $elementory,
            //'es_property_secondary-school' => $secondary,
            'es_property_management-fees' => $management,
            'es_property_cooling' => $cooling,
            'es_property_floor_level' => $floor_level,
            'category' => $category,
        ];

           
        // Check garage meta field exists
        $args = [
            'post_type' => 'properties',
            'meta_query' => [
                [
                    'key' => 'es_property_garage-spaces',
                    'value' => $garage,
                    'compare' => '='
                ]
            ],
            'posts_per_page' => 1
        ];
        $existing_posts = get_posts($args);


      
        if (!empty($existing_posts)) {
            $post_id = $existing_posts[0]->ID;

            $post_update_data = [
                'ID' => $post_id,
                'post_title' => $title,
                'post_type' => 'properties',
            ];

            $updated_post_id = wp_update_post($post_update_data);

            if (is_wp_error($updated_post_id)) {
                echo "Error updating post: " . $updated_post_id->get_error_message();
            } else {
                echo "Post ID: " . $post_id . "<br>";
                echo "Post updated successfully.";
            }
        } else {
            // No post found, create a new post
            $post_data = [
                'post_title' => $title,
                'post_type' => 'properties',
                'post_status' => 'publish',
            ];

            $new_post_id = wp_insert_post($post_data);

            if (is_wp_error($new_post_id)) {
                echo "Error creating post: " . $new_post_id->get_error_message();
            } else {
                echo "Post created successfully. Post ID: " . $new_post_id . "<br>";
                $post_id = $new_post_id; // Update the post ID variable
            }
        }

        // Update each meta field for the post
        if (isset($meta_fields) && is_array($meta_fields)) {
            foreach ($meta_fields as $key => $value) {
                update_post_meta($post_id, $key, $value);
            }
        }

    ?>















































// Output the JSON data
//header('Content-Type: application/json');




/*$input = file_get_contents('php://input');
// $input[''];
$data = json_decode($input, true);
echo "<pre>";
print_r($data);
echo "</pre>";
die();*/


/*$file = $_FILES['file'];
 $token_data = [
        'access_token' =>'test12',
        'expiry_timestamp' => 'test3',
        'data'=>$input,
        'files'=>json_encode($file)
    ];

$json_data = json_encode($token_data, JSON_PRETTY_PRINT);
$filename = 'accessToken.json';
file_put_contents($filename, $json_data);

if (!$data) {
    http_response_code(400);
    exit('Invalid data');
}

$post_id = $data['data']['id'] ?? null;
$updated_field = $data['data']['field_name'] ?? null; 

if ($post_id && $updated_field) {
    // Update the WordPress post meta with the received data
    $meta_key = 'your_meta_key'; // Replace with your meta key
    update_post_meta($post_id, $meta_key, $updated_field);
}

// Respond to Zoho
http_response_code(200);
echo 'Success';*/


?>

