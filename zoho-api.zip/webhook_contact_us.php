<?php 

$body = file_get_contents('php://input');

// $body = file_get_contents('res.log');
$decodedData = urldecode($body);
parse_str($decodedData, $output);

require_once 'accessToken.php';

if(isset($output['fields']['contact_zoho'])){
	$name = $output['fields']['name']['value'];
	$email = $output['fields']['email']['value'];
	$phone = $output['fields']['phone']['value'];
	$location = $output['fields']['location']['value'];
	$message = $output['fields']['message']['value'];

	$page_url = $output['meta']['page_url']['value'];


	// Contact data
	$contactData = [
	    "data" => [
	        [
	            "Last_Name" => $name,
	            "Email" => $email,
	            "Phone" => $phone,
	            "Mailing_City" => $location,
	            "Description" => $message,
	            'title' => "Contact Form",
	            "Website" => $page_url,
	        ]
	    ]
	];

	// Zoho CRM API URLs
	$leadUrl = 'https://www.zohoapis.com/crm/v2/Leads';

	// Lead data
	$leadData = [
	    "data" => [
	        [
	           // "Last_Name" => "devloper12 test",
	           // "Email" => "hiltworkdirectory2@gmail.com",
	           // "Phone" => "98456142211",
	           // "Street" => "Himachal",
	           // "Description" => "this is dummt text",
	           // "Lead_Source" => "Website Contact Us Form",
	            "Last_Name" => $name,
	            "Email" => $email,
	            "Phone" => $phone,
	            "Country" => $location,
	            "Description" => $message,
	            "Lead_Source" => $page_url,
	        ]
	    ]
	];

	// Create Contact
	$res = sendZohoRequest($leadUrl, $leadData, $accessToken);
	echo "<pre>";
	print_r($res);
	echo "</pre>";

}

// Function to send API request
function sendZohoRequest($url, $data, $accessToken) {
    // Convert the data to JSON
    $jsonData = json_encode($data);

    // Set up the HTTP headers
    $headers = [
        "Authorization: Zoho-oauthtoken " . $accessToken,
        "Content-Type: application/json"
    ];

    // Initialize cURL session
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Execute the request
    $response = curl_exec($ch);

    // Check for errors
    if(curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    } else {
        echo 'Response:' . $response;
    }

    // Close cURL session
    curl_close($ch);
}


