https://servdharm.com/?code=1000.540b049072c790b24fb442580aca9d5f.d02cbb52abfa005bad29bb340432d3bd&location=in&accounts-server=https%3A%2F%2Faccounts.zoho.in&

array:6 [▼
  "access_token" => "1000.3be3cb8df5afb8d65d10575356da31fe.2b5eed4ccb132e35c915f61a47479aa2"
  "refresh_token" => "1000.95900529c1ead5c3f20fe4b16e90535e.9f4f257a419d3a5505c157a1f8181665"
  "scope" => "ZohoInventory.fullaccess.all"
  "api_domain" => "https://www.zohoapis.in"
  "token_type" => "Bearer"
  "expires_in" => 3600
]


'https://www.zohoapis.in/inventory/v1/items?organization_id=60027981548'