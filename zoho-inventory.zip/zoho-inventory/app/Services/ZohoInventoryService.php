<?php

namespace App\Services;

use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;

class ZohoInventoryService
{
    protected $client;
    protected $apiUrl;

    public function __construct()
    {
        $this->client = new Client();
        $this->apiUrl = 'https://inventory.zoho.com/api/v1/';
    }

    public function test(){
        return 'test';
    }

    public function getAccessToken()
    {
        $url = "https://accounts.zoho.in/oauth/v2/token";
        $clientId = '1000.4XILKCLVM4T4YBSNW8SL5DKHDHSYZY';
        $clientSecret = 'ef6690ef9f86d4e294402f9bb050770d5399d58c68';
        $refreshToken = '1000.95900529c1ead5c3f20fe4b16e90535e.9f4f257a419d3a5505c157a1f8181665';
        // return $refreshToken;
        $file = storage_path('app/accessToken.json');
        $fileData = json_decode(file_get_contents($file),true);
        if(time() >= $fileData['expires_in']){ 
            try {
                $response = $this->client->request('POST', $url, [
                    'form_params' => [
                        'refresh_token' => $refreshToken,
                        'client_id' => $clientId,
                        'client_secret' => $clientSecret,
                        'grant_type' => 'refresh_token',
                    ],
                ]);

                $data = json_decode($response->getBody(), true);
                $data['expires_in'] = $data['expires_in']+ time();
                file_put_contents($file, json_encode($data, true));
                return $data['access_token'];

            } catch (\Exception $e) {
                Log::error('Failed to retrieve Zoho access token: ' . $e->getMessage());
                return null;
            }
        }
        return $fileData['access_token'];
    }


    public function fetchData($endpoint, $params = [])
    {
        $accessToken = $this->getAccessToken();
        $params = array_merge([
            'page' => 1,
            'per_page' => 20
        ], $params);
        try {
            $response = $this->client->request('GET', "https://www.zohoapis.in/inventory/v1/$endpoint?organization_id=60027981548", [
                'headers' => [
                    'Authorization' => "Zoho-oauthtoken $accessToken",
                ],
                'query' => $params,
            ]);
            return json_decode($response->getBody()->getContents(), true);
        } catch (\Exception $e) {
            Log::error('Zoho API Request Failed: ' . $e->getMessage());
            return null;
        }
    }

    public function createPackage($data,$salesorder_id)
    {
        $accessToken = $this->getAccessToken();
        $apiUrl = 'https://www.zohoapis.com/inventory/v1/packages?organization_id=60027981548&salesorder_id='.$salesorder_id; 

        try {
            $response = $this->client->request('POST', $apiUrl, [
                'headers' => [
                    'Authorization' => "Zoho-oauthtoken $accessToken",
                    'Content-Type' => 'application/json',
                ],
                'json' => $data,
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (\Exception $e) {
            Log::error('Zoho API Request Failed (Package Creation): ' . $e->getMessage());
            return null;
        }
    }

    public function createShipment($data, $endpoint)
    {
        $accessToken = $this->getAccessToken();
        $apiUrl = 'https://www.zohoapis.in/inventory/v1/shipmentorders?organization_id=60027981548'; // Replace with the correct endpoint

        try {
            $response = $this->client->request('POST', $apiUrl, [
                'headers' => [
                    'Authorization' => "Zoho-oauthtoken $accessToken",
                    'Content-Type' => 'application/json',
                ],
                'json' => $data, // Pass the shipment data here
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (\Exception $e) {
            Log::error('Zoho API Request Failed (Shipment Creation): ' . $e->getMessage());
            return null;
        }
    }


    public function getAccessTokenFromAuthCode()
    {
        $authorizationCode ="1000.540b049072c790b24fb442580aca9d5f.d02cbb52abfa005bad29bb340432d3bd";
        $url = "https://accounts.zoho.in/oauth/v2/token";
        $clientId = '1000.4XILKCLVM4T4YBSNW8SL5DKHDHSYZY';
        $clientSecret = 'ef6690ef9f86d4e294402f9bb050770d5399d58c68';
        $redirectUri = 'https://servdharm.com/';
        
        // return $authorizationCode;
        try {
            $response = $this->client->request('POST', $url, [
                'form_params' => [
                    'code' => $authorizationCode,
                    'client_id' => $clientId,
                    'client_secret' => $clientSecret,
                    'redirect_uri' => $redirectUri,
                    'grant_type' => 'authorization_code',
                ],
            ]);

            $data = json_decode($response->getBody(), true);
            // return $data;
            // $accessToken = $data['access_token'];
            // $refreshToken = $data['refresh_token'];

            
            // return ['access_token' => $accessToken, 'refresh_token' => $refreshToken];

        } catch (\Exception $e) {
            return  'Failed to retrieve Zoho tokens: ' . $e->getMessage();
             
        }
    }

}
