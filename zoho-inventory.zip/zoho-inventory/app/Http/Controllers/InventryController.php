<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ZohoInventoryService;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;
use App\Models\BlueDartDetail;
use function Ramsey\Uuid\v1;

class InventryController extends Controller
{
    protected $zohoService;

    public function __construct(ZohoInventoryService $zohoService)
    {
        $this->zohoService = $zohoService;
    }
    public function inventryList(Request $request){
        $page = $request->input('page', 1); 
        $datas = $this->zohoService->fetchData('salesorders', ['page' => $page, 'per_page' => 20]);
        $items = collect($datas['salesorders']);
        $brandData = $items->map(function ($item) {
           $lable = BlueDartDetail::where('salesorder_id',$item['salesorder_id'])->first();
           $item['lable'] =$lable->id ?? false;
            return $item;
        });
        $totalPages = $datas['total_pages'] ?? 1;
        return view('pages.salesOrdersList', [
            'datas' => $brandData,
            'currentPage' => $page,
            'totalPages' => $totalPages
        ]);
    }

    public function checkServiceForPincode(Request $request){
        $datas = $this->zohoService->fetchData('salesorders/'.$request->salesorder_id);
        $data = $datas['salesorder'];
        $file = storage_path('app/salesorderData.json');
        file_put_contents($file, json_encode($data, true));
        $shipping_address = $data['shipping_address'];
        $response = $this->getServicesForPincode($shipping_address['zip']);
        return response()->json($response);
    }

    public function getServicesForPincode($pincode) 
    {
        $url = 'https://apigateway-sandbox.bluedart.com/in/transportation/finder/v1/GetServicesforPincode';
        $jwtToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzdWJqZWN0LXN1YmplY3QiLCJhdWQiOlsiYXVkaWVuY2UxIiwiYXVkaWVuY2UyIl0sImlzcyI6InVybjpcL1wvYXBpZ2VlLWVkZ2UtSldULXBvbGljeS10ZXN0IiwiZXhwIjoxNzI1NTE1MDUxLCJpYXQiOjE3MjU0Mjg2NTEsImp0aSI6ImRlZmRiZjlkLTIyM2EtNDIwOC04ZTA0LWNjMTFkZjBjMzc3NSJ9.F9KasXNB74lnVgK7z_UlHwCv8h-9psY2NXJkwxNaHXI';  
        $file = storage_path('app/blueDartData.json');
        $fileData = json_decode(file_get_contents($file),true);
        $requestData = [
            'pinCode' => $pincode,  
            "profile" => $fileData['Profile']
        ];
        
        $response = Http::withHeaders([
            'JWTToken' => $jwtToken,
            'Content-Type' => 'application/json'
        ])->post($url, $requestData);
        
        if ($response->successful()) {
            $datas = $response->json();
            $data = $datas['GetServicesforPincodeResult'];
            if($data['Embargo']=='No'){
                return [
                    'eTailPrePaidAirOutbound' => $data['eTailPrePaidAirOutound'] ?? 'No',
                    'eTailPrePaidGroundInbound' => $data['eTailPrePaidGroundInbound'] ?? 'No',
                    'eTailPrePaidGroundOutbound' => $data['eTailPrePaidGroundOutbound'] ?? 'No',
                ];
            }else{
                return 'Embargo Yes';
            }
        }
        
        return $response->json();
    }

    public function GenerateWayBill(Request $request) 
    {
        $url = 'https://apigateway-sandbox.bluedart.com/in/transportation/waybill/v1/GenerateWayBill';
        $jwtToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzdWJqZWN0LXN1YmplY3QiLCJhdWQiOlsiYXVkaWVuY2UxIiwiYXVkaWVuY2UyIl0sImlzcyI6InVybjpcL1wvYXBpZ2VlLWVkZ2UtSldULXBvbGljeS10ZXN0IiwiZXhwIjoxNzI1NTE1MDUxLCJpYXQiOjE3MjU0Mjg2NTEsImp0aSI6ImRlZmRiZjlkLTIyM2EtNDIwOC04ZTA0LWNjMTFkZjBjMzc3NSJ9.F9KasXNB74lnVgK7z_UlHwCv8h-9psY2NXJkwxNaHXI';  
    
        $date = date("Y-m-d H:i:s");
        $date = Carbon::parse($date)->timestamp * 1000;
        $file = storage_path('app/blueDartData.json');
        $wayBillData = json_decode(file_get_contents($file),true);

        $salesOrderFile = storage_path('app/salesorderData.json');
        $salesorderData = json_decode(file_get_contents($salesOrderFile),true);
       
        $salesorder_id =$salesorderData['salesorder_id'];
        $salesorder_number =$salesorderData['salesorder_number'];
        $reference_number =$salesorderData['reference_number'];
        $customer_id =$salesorderData['customer_id'];
        $customer_name =$salesorderData['customer_name'];
        $created_by_name =$salesorderData['created_by_name'];
        $branch_id =$salesorderData['branch_id'];
        $branch_name =$salesorderData['branch_name'];
        $amount =$salesorderData['total'];
        $created_time =$salesorderData['created_time'];
        $shipping_address =$salesorderData['shipping_address'];
        $invoices =$salesorderData['invoices'];
        $contact_person_details =$salesorderData['contact_person_details'];
        
        $wayBillData['Request']['Services']['Dimensions'] =[
                                                            "Breadth" => $request->breadth,
                                                            "Count" =>1,
                                                            "Height" => $request->height,
                                                            "Length" =>$request->length
                                                        ];
        $wayBillData['Request']['Services']['CreditReferenceNo'] ="2273410026291117";
        $wayBillData['Request']['Services']['PickupDate'] ="/Date($date)/";

        $wayBillData['Request']['Services']['itemdtl'] =[];
        foreach ($salesorderData['line_items'] as $lineItem) {
            $wayBillData['Request']['Services']['itemdtl'][] = [
                "CGSTAmount" => 0,
                "HSCode" => "",
                "IGSTAmount" => 0,
                "Instruction" => "",
                "InvoiceDate" => "/Date($date)/",
                "InvoiceNumber" => "",
                "ItemID" => substr($lineItem['item_id'], -15),
                "ItemName" => $lineItem['name'],
                "ItemValue" => 100,
                "Itemquantity" => $lineItem['quantity'],
                "PlaceofSupply" => "",
                "ProductDesc1" => "",
                "ProductDesc2" => "",
                "ReturnReason" => "",
                "SGSTAmount" => 0,
                "SKUNumber" => $lineItem['sku'],
                "SellerGSTNNumber" => "",
                "SellerName" => "",
                "SubProduct1" => "Test Sub 1",
                "SubProduct2" => "Test Sub 2",
                "TaxableAmount" =>$lineItem['line_item_taxes'][0]['tax_amount'],
                "TotalValue" => 100,
                "cessAmount" => "0.0",
                "countryOfOrigin" => "",
                "docType" => "",
                "subSupplyType" => 0,
                "supplyType" => ""
            ];
        }
       
        // dd($wayBillData['RegisterPickup']['AWBNo']);
        $wayBillData['Request']['Shipper'] =
        [
            "CustomerAddress1" => $shipping_address['address'] ?? '',
            "CustomerAddress2" => $shipping_address['street2'] ?? '',
            "CustomerAddress3" => "Test Cust Addr3",
            "CustomerAddressinfo" => "",
            "CustomerBusinessPartyTypeCode" => "",
            "CustomerCode" => "246525",
            "CustomerEmailID" => $contact_person_details[0]['email'] ?? null,
            "CustomerGSTNumber" => "",
            "CustomerLatitude" => "",
            "CustomerLongitude" => "",
            "CustomerMaskedContactNumber" => "",
            "CustomerMobile" => $contact_person_details[0]['mobile'] ?? null,
            "CustomerName" => $customer_name,
            "CustomerPincode" => $shipping_address['zip'],
            "CustomerTelephone" => "",
            "IsToPayCustomer" => true,
            "OriginArea" => "DEL",
            "Sender" => $salesorderData['created_by_name'],
            "VendorCode" => ""
        ];
        $response = Http::withHeaders([
            'JWTToken' => $jwtToken,
            'Content-Type' => 'application/json'
            ])->post($url, $wayBillData);
            
            // dd($response->json());
        if ($response->successful()) {
            $datas = $response->json();
            $data = $datas['GenerateWayBillResult'];
            $blue =   BlueDartDetail::create([
                    'salesorder_id' => $salesorder_id,
                    'awb_no' => $data['AWBNo'] ?? 0,
                    'token_number' => $data['TokenNumber'] ?? 0,
                    'invoice_id' => $invoices[0]['invoice_id'] ?? 0,
                    'total_amount' => $salesorderData['total'],
                    'phone_number' => $contact_person_details[0]['mobile'] ?? null,
                    'invoice_date' => $invoices[0]['date'] ?? 0,
                    'ship_to' => json_encode($shipping_address,true),
                ]);
              if($data['AWBNo']){
                    $register_pickup = $this->registerPickup($data['AWBNo'],$wayBillData,$date);
                    if($register_pickup){
                        return response()->json([
                            'status_code' => 1,
                            'status' => 'success',
                            'data' => $data,
                        ]);
                    }
              }
        }

        return response()->json([
           'status_code' => 2,
           'status' => 'error',
           'message' => 'Try Again.',
           'data' =>$response->json()
        ]);
    }


    public function registerPickup($AWBNo, $wayBillData,$date){
        $url = 'https://apigateway-sandbox.bluedart.com/in/transportation/pickup/v1/RegisterPickup';
        $jwtToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzdWJqZWN0LXN1YmplY3QiLCJhdWQiOlsiYXVkaWVuY2UxIiwiYXVkaWVuY2UyIl0sImlzcyI6InVybjpcL1wvYXBpZ2VlLWVkZ2UtSldULXBvbGljeS10ZXN0IiwiZXhwIjoxNzI1NTE1MDUxLCJpYXQiOjE3MjU0Mjg2NTEsImp0aSI6ImRlZmRiZjlkLTIyM2EtNDIwOC04ZTA0LWNjMTFkZjBjMzc3NSJ9.F9KasXNB74lnVgK7z_UlHwCv8h-9psY2NXJkwxNaHXI';
        $wayBillData['RegisterPickup']['AWBNo'] =[$AWBNo];
        $wayBillData['RegisterPickup']['ShipmentPickupDate'] ="/Date($date)/";
        // ShipmentPickupDate
        $requestData = [
            'request' =>$wayBillData['RegisterPickup'],  
            "profile" => $wayBillData['Profile']
        ];
        // return $requestData;
        $response = Http::withHeaders([
            'JWTToken' => $jwtToken,
            'Content-Type' => 'application/json'
        ])->post($url, $requestData);
        
        if ($response->successful()) {
            return true;
        }
        
        return false;
    
    }

    
}
