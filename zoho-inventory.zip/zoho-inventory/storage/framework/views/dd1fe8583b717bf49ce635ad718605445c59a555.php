<?php $attributes = $attributes->exceptProps(['message'=>null,'id'=>null]); ?>
<?php foreach (array_filter((['message'=>null,'id'=>null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="display: flex; justify-content: space-between;">
        <h5 class="modal-title" id="exampleModalLongTitle">Blue Dart Shipment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="POST" id="blueDartShiping">
          <?php echo csrf_field(); ?>
          <div class="form-group">
              <label for="breadth">Breadth (in cm):</label>
              <input type="text" name="breadth" class="form-control" id="breadth" placeholder="Enter Breadth" required>
          </div>

          <div class="form-group">
              <label for="height">Height (in cm):</label>
              <input type="text" name="height" class="form-control" id="height" placeholder="Enter Height" required>
          </div>

          <div class="form-group">
              <label for="length">Length (in cm):</label>
              <input type="text" name="length" class="form-control" id="length" placeholder="Enter Length" required>
          </div>

          <div class="form-group">
              <label for="weight">Weight (in kg):</label>
              <input type="text" name="weight" class="form-control" id="weight" placeholder="Enter Weight" required>
          </div>

          <div class="form-group">
              <label>Available Services:</label><br>

            <div class="checkBoxGroup">
      
            </div>
          </div>
         <div class="modal-footer">
           <button type="submit" class="btn btn-primary">Submit</button>
           <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         </div>
        </form>
      </div>
    
    </div>
  </div>
</div><?php /**PATH C:\Users\Technology\Desktop\zoho inventory\zoho-inventory\resources\views/components/shipModal.blade.php ENDPATH**/ ?>