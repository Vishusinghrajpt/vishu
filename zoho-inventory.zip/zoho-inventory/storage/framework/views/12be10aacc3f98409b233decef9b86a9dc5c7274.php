<script src="<?php echo e(asset('assets/js/jquery-1.10.2.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.metisMenu.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/morris/raphael-2.1.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/morris/morris.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script><?php /**PATH C:\Users\Technology\Desktop\zoho inventory\zoho-inventory\resources\views/include/footer.blade.php ENDPATH**/ ?>