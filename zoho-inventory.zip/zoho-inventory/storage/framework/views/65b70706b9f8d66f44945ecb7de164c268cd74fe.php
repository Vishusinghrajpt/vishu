<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <!-- @vite(['resources/css/app.css', 'resources/js/app.js']) -->
         <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php echo $__env->yieldPushContent('css'); ?>
    </head>
    <body>
        <!-- <div id="wrapper"> -->
            <?php echo $__env->make('include.topNavBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- </div> -->
    </body>
    <?php echo $__env->yieldPushContent('js'); ?>
</html><?php /**PATH C:\Users\Technology\Desktop\zoho inventory\zoho-inventory\resources\views/layouts/default.blade.php ENDPATH**/ ?>