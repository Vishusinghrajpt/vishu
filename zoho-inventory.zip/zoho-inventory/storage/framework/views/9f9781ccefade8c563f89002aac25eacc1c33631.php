

<?php $__env->startSection('title'); ?> Home <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="page-wrapper1">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        Responsive Table Example
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Sales Order Id</th>
                                        <th>Customer Name</th>
                                        <th>Email</th>
                                        <th>Total Amount</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php 
                                $salesorder_id = $data['salesorder_id'];
                                ?>
                                    <tr>
                                        <td><?php echo e($data['salesorder_id'] ?? ''); ?></td>
                                        <td><?php echo e($data['customer_name'] ?? ''); ?></td>
                                        <td><?php echo e($data['email'] ?? ''); ?></td>
                                        <td><?php echo e($data['total'] ?? ''); ?></td>
                                        <td>
                                            <?php if($data['invoiced_status'] == 'invoiced'): ?>
                                              <?php if($data['lable']): ?>
                                              <a href="<?php echo e(route('generateInvoice', ['salesorder_id' => $data['salesorder_id']])); ?>">
                                                <button class="btn btn-success">Label</button>
                                              </a>
                                              <?php else: ?>
                                                  <button class="btn btn-success" onclick="shipModel('<?php echo e($salesorder_id); ?>')">Ship</button>
                                              <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="pagination" style="display:flex;justify-content:end;">
                                <?php if($currentPage > 1): ?>
                                    <a class="btn btn-success" href="<?php echo e(url()->current() . '?page=' . ($currentPage - 1)); ?>" style="margin-right: 10px;">Previous</a>
                                <?php endif; ?>

                                <?php if($currentPage): ?>
                                    <a class="btn btn-success ms-3" href="<?php echo e(url()->current() . '?page=' . ($currentPage + 1)); ?>">Next</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.shipModal','data' => ['message' => 'test','id' => 'shipModal']]); ?>
<?php $component->withName('shipModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['message' => 'test','id' => 'shipModal']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script type="text/javascript">
function shipModel($data){

    $.ajax({
     url: "<?php echo e(route('GetServicesforPincode')); ?>",
        type: 'POST',
        data: {
            _token: '<?php echo e(csrf_token()); ?>',
            salesorder_id: $data,
        },
        success: function(response) {
            console.log(response);

            var checkBoxGroup = '';
            if (response.eTailPrePaidAirOutbound === "Yes") {
                checkBoxGroup += `<div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidAirOutbound" value="eTailPrePaidAirOutbound" required>
                    <label class="form-check-label" for="eTailPrePaidAirOutbound">eTail PrePaid Air Outbound</label>
                </div>`;
            }

            if (response.eTailPrePaidGroundInbound === "Yes") {
                checkBoxGroup += `<div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidGroundInbound" value="eTailPrePaidGroundInbound" required>
                    <label class="form-check-label" for="eTailPrePaidGroundInbound">eTail PrePaid Ground Inbound</label>
                </div>`;
            }

            if (response.eTailPrePaidGroundOutbound === "Yes") {
                checkBoxGroup += `<div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidGroundOutbound" value="eTailPrePaidGroundOutbound" required>
                    <label class="form-check-label" for="eTailPrePaidGroundOutbound">eTail PrePaid Ground Outbound</label>
                </div>`;
            }

            if (checkBoxGroup === '') {
                checkBoxGroup = '<p>No services available for the selected pincode.</p>';
            }

            $('.checkBoxGroup').html(checkBoxGroup);
            $('#shipModal').modal('show');
        },
        error: function(xhr, status, error) {
            console.log('Error: ', error);
        }
    });
}

$('#blueDartShiping').on('submit', function(e){
    e.preventDefault();
    var formData = $(this).serialize();
    $.ajax({
        url: "<?php echo e(route('ShipOrder')); ?>",
        type: 'POST',
        data: formData,
        success: function(response) {
            // console.log(response);
        $('#shipModal').modal('hide');
        if(response.status_code == 1){
           alert('Order has been shipped successfully.');
        }else{
            alert('Failed to ship the order.');
        }
            location.reload(); 
        },
        error: function(xhr, status, error) {
            console.log('Error: ', error);
        }
    });

})
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Technology\Desktop\zoho inventory\zoho-inventory\resources\views/pages/salesOrdersList.blade.php ENDPATH**/ ?>