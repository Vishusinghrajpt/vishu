<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title><?php echo $__env->yieldContent('title'); ?></title>
<link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/css/font-awesome.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/js/morris/morris-0.4.3.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' /><?php /**PATH C:\Users\Technology\Desktop\zoho inventory\zoho-inventory\resources\views/include/header.blade.php ENDPATH**/ ?>