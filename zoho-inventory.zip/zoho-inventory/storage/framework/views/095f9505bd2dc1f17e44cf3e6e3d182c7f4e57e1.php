
<style>
    table {
  font-family: "Roboto", sans-serif;
  
}
</style>
<table cellspacing="0" cellpadding="5" width="100%" border="1px">
  <tr>
    <td colspan="2">
      <strong>Shop to</strong>: <?php echo e($ship_to ?? ''); ?><br /><?php echo e($phone_number ?? ''); ?>

    </td>
  </tr>
  <tr>
    <td colspan="2" align="center">
      <p>
        <strong> Bluedart: <?php echo e($awb_no ?? ''); ?> </strong>
      </p>
      <?php echo DNS1D::getBarcodeHTML($awb_no, 'C39'); ?>

    </td>
  </tr>
  <tr>
    <td>
      <strong>
        Amount to be collected<br />COD<br />Rs <?php echo e($amount ?? 0); ?>.00<br />
        (<?php echo e($amountInString ?? ''); ?>)
      </strong>
    </td>
    <td>
      <table width="100%">
        <tr>
          <td><strong>Route Code:</strong></td>
          <td align="right">DEL/RED/RED</td>
        </tr>
        <tr>
          <td><strong>Order Date:</strong></td>
          <td align="right"><?php echo e($created_at ?? ''); ?></td>
        </tr>
        <tr>
          <td><strong>Invoice Number:</strong></td>
          <td align="right"><?php echo e($invoice_id ?? ''); ?></td>
        </tr>
        <tr>
          <td><strong>Invoice Date:</strong></td>
          <td align="right"><?php echo e($invoice_date ?? ''); ?></td>
        </tr>
        <tr>
          <td><strong>Pieces:</strong></td>
          <td align="right">1</td>
        </tr>
      </table>
    </td>
    
  </tr>
  <tr>
    <td colspan="2">
        Order Id: <?php echo e($salesorder_id ?? ''); ?>

    </td>
  </tr>
  <tr>
    <td colspan="2" height="200px"></td>
  </tr>
  <tr>
    <td>Order Total: </td>
    <td align="right">Rs <?php echo e($amount ?? ''); ?>.00</td>
  </tr>
  <tr>
    <td colspan="2">
        <strong><p>Return Address:</strong> D53, Nangal Dewat, Sector D, Vasant Kunj, New Delhi, South
        West Delhi, South West Delhi, Delhi, India, 110070</p>
        <p><strong>GSTIN No.:</strong> 07AASFT1911F1Z5</p>
    </td>
  </tr>
</table>
<?php /**PATH C:\Users\Technology\Desktop\zoho inventory\zoho-inventory\resources\views/pdf/invoice.blade.php ENDPATH**/ ?>