<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InventryController;
use App\Http\Controllers\InvoiceController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
   return redirect()->route('inventryList');;
})->middleware(['auth']);


Route::get('/generate-invoice', [InvoiceController::class, 'generateInvoice'])->name('generateInvoice');

Route::prefix('admin')->middleware('auth')->group(function () {
    Route::controller(InventryController::class)->group(function () {
        Route::get('/zoho-inventry-list', 'inventryList')->name('inventryList');
        Route::post('/GetServicesforPincode', 'checkServiceForPincode')->name('GetServicesforPincode');
        Route::post('/GenerateWayBill', 'GenerateWayBill')->name('ShipOrder');
    });
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';
