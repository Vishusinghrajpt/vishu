
@extends('layouts.default')
@section('title') Home @endsection

@section('content')

<div id="page-wrapper1">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        Responsive Table Example
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Sales Order Id</th>
                                        <th>Customer Name</th>
                                        <th>Email</th>
                                        <th>Total Amount</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @foreach($datas as $data)
                                @php 
                                $salesorder_id = $data['salesorder_id'];
                                @endphp
                                    <tr>
                                        <td>{{$data['salesorder_id'] ?? ''}}</td>
                                        <td>{{$data['customer_name'] ?? ''}}</td>
                                        <td>{{$data['email'] ?? ''}}</td>
                                        <td>{{$data['total'] ?? ''}}</td>
                                        <td>
                                            @if($data['invoiced_status'] == 'invoiced')
                                              @if($data['lable'])
                                              <a href="{{ route('generateInvoice', ['salesorder_id' => $data['salesorder_id']]) }}">
                                                <button class="btn btn-success">Label</button>
                                              </a>
                                              @else
                                                  <button class="btn btn-success" onclick="shipModel('{{ $salesorder_id }}')">Ship</button>
                                              @endif
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            <div class="pagination" style="display:flex;justify-content:end;">
                                @if ($currentPage > 1)
                                    <a class="btn btn-success" href="{{ url()->current() . '?page=' . ($currentPage - 1) }}" style="margin-right: 10px;">Previous</a>
                                @endif

                                @if ($currentPage)
                                    <a class="btn btn-success ms-3" href="{{ url()->current() . '?page=' . ($currentPage + 1) }}">Next</a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<x-shipModal message="test" id="shipModal" />
@endsection

@push('js')
<script type="text/javascript">
function shipModel($data){

    $.ajax({
     url: "{{ route('GetServicesforPincode') }}",
        type: 'POST',
        data: {
            _token: '{{ csrf_token() }}',
            salesorder_id: $data,
        },
        success: function(response) {
            console.log(response);

            var checkBoxGroup = '';
            if (response.eTailPrePaidAirOutbound === "Yes") {
                checkBoxGroup += `<div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidAirOutbound" value="eTailPrePaidAirOutbound" required>
                    <label class="form-check-label" for="eTailPrePaidAirOutbound">eTail PrePaid Air Outbound</label>
                </div>`;
            }

            if (response.eTailPrePaidGroundInbound === "Yes") {
                checkBoxGroup += `<div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidGroundInbound" value="eTailPrePaidGroundInbound" required>
                    <label class="form-check-label" for="eTailPrePaidGroundInbound">eTail PrePaid Ground Inbound</label>
                </div>`;
            }

            if (response.eTailPrePaidGroundOutbound === "Yes") {
                checkBoxGroup += `<div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="service_type" id="eTailPrePaidGroundOutbound" value="eTailPrePaidGroundOutbound" required>
                    <label class="form-check-label" for="eTailPrePaidGroundOutbound">eTail PrePaid Ground Outbound</label>
                </div>`;
            }

            if (checkBoxGroup === '') {
                checkBoxGroup = '<p>No services available for the selected pincode.</p>';
            }

            $('.checkBoxGroup').html(checkBoxGroup);
            $('#shipModal').modal('show');
        },
        error: function(xhr, status, error) {
            console.log('Error: ', error);
        }
    });
}

$('#blueDartShiping').on('submit', function(e){
    e.preventDefault();
    var formData = $(this).serialize();
    $.ajax({
        url: "{{ route('ShipOrder') }}",
        type: 'POST',
        data: formData,
        success: function(response) {
            // console.log(response);
        $('#shipModal').modal('hide');
        if(response.status_code == 1){
           alert('Order has been shipped successfully.');
        }else{
            alert('Failed to ship the order.');
        }
            location.reload(); 
        },
        error: function(xhr, status, error) {
            console.log('Error: ', error);
        }
    });

})
</script>

@endpush