
<style>
    table {
  font-family: "Roboto", sans-serif;
  
}
</style>
<table cellspacing="0" cellpadding="5" width="100%" border="1px">
  <tr>
    <td colspan="2">
      <strong>Shop to</strong>: {{$ship_to ?? ''}}<br />{{$phone_number ?? ''}}
    </td>
  </tr>
  <tr>
    <td colspan="2" align="center">
      <p>
        <strong> Bluedart: {{$awb_no ?? ''}} </strong>
      </p>
      {!! DNS1D::getBarcodeHTML($awb_no, 'C39') !!}
    </td>
  </tr>
  <tr>
    <td>
      <strong>
        Amount to be collected<br />COD<br />Rs {{$amount ?? 0}}.00<br />
        ({{$amountInString ?? ''}})
      </strong>
    </td>
    <td>
      <table width="100%">
        <tr>
          <td><strong>Route Code:</strong></td>
          <td align="right">DEL/RED/RED</td>
        </tr>
        <tr>
          <td><strong>Order Date:</strong></td>
          <td align="right">{{$created_at ?? ''}}</td>
        </tr>
        <tr>
          <td><strong>Invoice Number:</strong></td>
          <td align="right">{{$invoice_id ?? ''}}</td>
        </tr>
        <tr>
          <td><strong>Invoice Date:</strong></td>
          <td align="right">{{$invoice_date ?? ''}}</td>
        </tr>
        <tr>
          <td><strong>Pieces:</strong></td>
          <td align="right">1</td>
        </tr>
      </table>
    </td>
    
  </tr>
  <tr>
    <td colspan="2">
        Order Id: {{$salesorder_id ?? ''}}
    </td>
  </tr>
  <tr>
    <td colspan="2" height="200px"></td>
  </tr>
  <tr>
    <td>Order Total: </td>
    <td align="right">Rs {{$amount ?? ''}}.00</td>
  </tr>
  <tr>
    <td colspan="2">
        <strong><p>Return Address:</strong> D53, Nangal Dewat, Sector D, Vasant Kunj, New Delhi, South
        West Delhi, South West Delhi, Delhi, India, 110070</p>
        <p><strong>GSTIN No.:</strong> 07AASFT1911F1Z5</p>
    </td>
  </tr>
</table>
