<nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="/">Blue Dart</a>
    </div>

    @auth
    <div style="color: white;
            padding: 15px 50px 5px 50px;
            float: right;
            font-size: 16px;">
        <form method="post" action="{{ route('logout') }}" id="logoutForm">
            @csrf
            <a href="javascript:;" onclick="document.getElementById('logoutForm').submit()" class="btn btn-danger square-btn-adjust">Logout</a>
        </form>

    </div>
    @else
    {{--<div style="color: white;
            padding: 15px 50px 5px 20px;
            float: right;
            font-size: 16px;">
        <a href="/register" class="btn btn-danger square-btn-adjust">Register</a>
    </div>
    <div style="color: white;
            padding: 15px 0px 5px 50px;
            float: right;
            font-size: 16px;">
        <a href="/login" class="btn btn-danger square-btn-adjust">Login</a>
    </div>--}}
    @endauth
</nav>